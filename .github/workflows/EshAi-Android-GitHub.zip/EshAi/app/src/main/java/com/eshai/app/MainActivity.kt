package com.eshai.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151C30)
private val Blue = Color(0xFF4F8CFF)
private val Purple = Color(0xFF8B5CF6)
private val MainText = Color(0xFFF5F7FF)
private val Muted = Color(0xFF9AA6C0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EshAiTheme { EshAiHome() } }
    }
}

@Composable
private fun EshAiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, secondary = Purple, background = Bg, surface = Panel,
        onPrimary = Color.White, onBackground = MainText, onSurface = MainText
    ), content = content)
}

private enum class Tab(val label: String) { CHAT("Chat"), CHESS("Chess Analyzer"), CONVERT("File Converter") }
private data class ChatLine(val fromUser: Boolean, val text: String)

@Composable
private fun EshAiHome() {
    var tab by remember { mutableStateOf(Tab.CHAT) }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.fillMaxSize()) {
            Header()
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tab.entries.forEach { item ->
                    val selected = item == tab
                    Surface(
                        onClick = { tab = item },
                        color = if (selected) Blue.copy(alpha = .18f) else Panel,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).border(1.dp, if (selected) Blue else Color.Transparent, RoundedCornerShape(14.dp))
                    ) { Text(item.label, Modifier.padding(vertical = 12.dp, horizontal = 6.dp), color = if (selected) MainText else Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            Spacer(Modifier.height(10.dp))
            when (tab) {
                Tab.CHAT -> ChatScreen()
                Tab.CHESS -> ChessScreen()
                Tab.CONVERT -> ConverterScreen()
            }
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(BrushesEshAi, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("EshAi", color = MainText, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("PRIVATE · ON-DEVICE WORKSPACE", color = Muted, fontSize = 9.sp, letterSpacing = 1.1.sp)
        }
        Surface(color = Color(0xFF123A31), shape = RoundedCornerShape(50)) {
            Text("OFFLINE MVP", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color(0xFF6EE7B7), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private val BrushesEshAi = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Blue, Purple))

@Composable
private fun ChatScreen() {
    val context = LocalContext.current
    var prompt by remember { mutableStateOf("") }
    var pickedName by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(ChatLine(false, "Halo! Saya EshAi. Versi awal ini menyediakan chat lokal dasar dan alat file. Mesin LLM lokal belum disertakan di paket ini.")) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedName = queryDisplayName(context, uri) ?: uri.lastPathSegment ?: "File dipilih"
            messages.add(ChatLine(false, "File dipilih: $pickedName. Buka tab File Converter untuk konversi format yang didukung."))
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) prompt = listOf(prompt, spoken).filter { it.isNotBlank() }.joinToString(" ")
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(messages) { line ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (line.fromUser) Alignment.End else Alignment.Start) {
                    Surface(color = if (line.fromUser) Color(0xFF233B68) else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 330.dp)) {
                        Text(line.text, Modifier.padding(14.dp), color = MainText, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                }
            }
        }
        if (pickedName.isNotBlank()) Text("Lampiran terakhir: $pickedName", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
            Column(Modifier.padding(10.dp)) {
                BasicTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 42.dp).padding(8.dp), textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 14.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Blue), decorationBox = { inner -> if (prompt.isEmpty()) Text("Tulis pesan... (chat demo offline)", color = Muted, fontSize = 14.sp); inner() })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Icon(Icons.Default.AttachFile, "Pilih file", tint = Muted) }
                    IconButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bicara untuk mengisi teks")
                        }
                        try { speechLauncher.launch(intent) } catch (_: Exception) { Toast.makeText(context, "Speech recognition tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show() }
                    }) { Icon(Icons.Default.Mic, "Speak to write", tint = Muted) }
                    Spacer(Modifier.weight(1f))
                    FilledIconButton(onClick = {
                        val sent = prompt.trim()
                        if (sent.isNotEmpty()) {
                            messages.add(ChatLine(true, sent))
                            messages.add(ChatLine(false, offlineReply(sent)))
                            prompt = ""
                        }
                    }) { Icon(Icons.Default.Send, "Kirim") }
                }
            }
        }
    }
}

private fun offlineReply(input: String): String {
    val q = input.lowercase(Locale.ROOT)
    return when {
        "halo" in q || "hai" in q -> "Halo! Chat pada build awal ini berjalan lokal dengan respons sederhana. Untuk kemampuan generatif, integrasikan model LLM on-device seperti LiteRT-LM atau llama.cpp."
        "pdf" in q || "word" in q || "convert" in q || "konversi" in q -> "Buka tab File Converter. Build awal mendukung konversi teks/CSV/HTML/Markdown ke beberapa format teks dan pembuatan PDF sederhana. PDF↔DOCX dan Office lengkap belum tersedia pada build ini."
        "offline" in q -> "Antarmuka dan fungsi konversi dasar berjalan lokal. Pengenalan suara Android dapat bergantung pada dukungan offline dari layanan speech di perangkat. Model LLM dan Stockfish belum dibundel dalam MVP ini."
        else -> "Pesan diterima secara lokal. Ini masih mode demo tanpa model LLM generatif. Kode antarmuka dan konverter dasar dapat dikembangkan dengan menghubungkan mesin AI lokal."
    }
}

@Composable
private fun ConverterScreen() {
    val context = LocalContext.current
    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceName by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("PDF") }
    var status by remember { mutableStateOf("Pilih file untuk melihat opsi konversi yang tersedia.") }
    val targets = listOf("PDF", "TXT", "HTML", "MD", "PNG", "JPG", "WEBP")
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        sourceUri = uri
        sourceName = uri?.let { queryDisplayName(context, it) ?: it.lastPathSegment ?: "File" }.orEmpty()
        status = if (uri == null) "Tidak ada file dipilih." else "Terpilih: $sourceName\nTarget yang dipilih: $target. Dukungan tergantung format sumber."
    }
    val outputPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { outUri ->
        val input = sourceUri
        if (input != null && outUri != null) {
            try {
                val sourceExt = sourceName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                context.contentResolver.openInputStream(input).use { inputStream ->
                    requireNotNull(inputStream) { "Tidak dapat membuka file sumber." }
                    when (target) {
                        "PDF" -> {
                            val text = readTextForSupportedSource(inputStream, sourceExt)
                            writeSimplePdf(context, outUri, text)
                        }
                        "TXT", "HTML", "MD" -> {
                            val raw = readTextForSupportedSource(inputStream, sourceExt)
                            val converted = when (target) {
                                "HTML" -> "<!doctype html><html><head><meta charset=\"utf-8\"></head><body><pre>${escapeHtml(raw)}</pre></body></html>"
                                "MD" -> if (sourceExt == "html") raw.replace(Regex("<[^>]*>"), " ") else raw
                                else -> if (sourceExt == "html") raw.replace(Regex("<[^>]*>"), " ") else raw
                            }
                            context.contentResolver.openOutputStream(outUri).use { os -> requireNotNull(os).write(converted.toByteArray(Charsets.UTF_8)) }
                        }
                        "PNG", "JPG", "WEBP" -> {
                            require(sourceExt in listOf("png", "jpg", "jpeg", "webp", "bmp")) { "Target gambar hanya mendukung sumber gambar umum (PNG/JPG/WEBP/BMP)." }
                            val bytes = context.contentResolver.openInputStream(input).use { requireNotNull(it).readBytes() }
                            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("Gambar tidak dapat dibaca.")
                            context.contentResolver.openOutputStream(outUri).use { os ->
                                requireNotNull(os)
                                val format = when (target) { "PNG" -> Bitmap.CompressFormat.PNG; "JPG" -> Bitmap.CompressFormat.JPEG; else -> Bitmap.CompressFormat.WEBP }
                                val quality = if (target == "PNG") 100 else 90
                                check(bitmap.compress(format, quality, os)) { "Gagal mengodekan gambar." }
                            }
                            bitmap.recycle()
                        }
                    }
                }
                status = "Berhasil menyimpan hasil $target. Periksa file hasil sebelum digunakan."
            } catch (e: Exception) {
                status = "Konversi gagal: ${e.message ?: "format belum didukung"}"
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("File Converter", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = MainText)
        Text("Konversi lokal untuk format yang didukung. File tidak dikirim ke server.", color = Muted, fontSize = 13.sp)
        Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(8.dp)); Text("Pilih file") }
        if (sourceName.isNotBlank()) Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Text(sourceName, Modifier.padding(14.dp), color = MainText) }
        Text("Format tujuan", color = MainText, fontWeight = FontWeight.SemiBold)
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(target); Spacer(Modifier.weight(1f)); Text("▾") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                targets.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { target = option; expanded = false }) }
            }
        }
        Button(onClick = {
            val uri = sourceUri
            if (uri == null) status = "Pilih file terlebih dahulu."
            else {
                val ext = when (target) { "PDF" -> "pdf"; "TXT" -> "txt"; "HTML" -> "html"; "MD" -> "md"; "PNG" -> "png"; "JPG" -> "jpg"; else -> "webp" }
                outputPicker.launch("${sourceName.substringBeforeLast('.', sourceName)}_converted.$ext")
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Konversi dan simpan") }
        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Text(status, Modifier.padding(14.dp), color = Muted, fontSize = 13.sp, lineHeight = 19.sp) }
        Text("Catatan: PDF di sini dibuat dari teks sederhana. PDF hasil scan, DOCX, XLSX, PPTX, audio/video, dan arsip belum didukung pada build MVP.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

private fun readTextForSupportedSource(input: java.io.InputStream, ext: String): String {
    require(ext in listOf("txt", "md", "csv", "html", "htm", "json", "xml", "log")) {
        "Sumber .$ext belum didukung untuk konversi teks pada MVP. Gunakan TXT, MD, CSV, HTML, JSON, XML, atau LOG."
    }
    return BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }
}

private fun escapeHtml(value: String): String = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

private fun writeSimplePdf(context: android.content.Context, uri: Uri, text: String) {
    val document = PdfDocument()
    val paint = Paint().apply { color = android.graphics.Color.BLACK; textSize = 11f; isAntiAlias = true }
    val pageWidth = 595
    val pageHeight = 842
    val margin = 40f
    val lineHeight = 16f
    val maxChars = 85
    val lines = text.lines().flatMap { line -> if (line.length <= maxChars) listOf(line) else line.chunked(maxChars) }.ifEmpty { listOf("") }
    var index = 0
    var pageNumber = 1
    while (index < lines.size) {
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        val page = document.startPage(pageInfo)
        var y = margin + 12f
        while (index < lines.size && y < pageHeight - margin) {
            page.canvas.drawText(lines[index], margin, y, paint)
            y += lineHeight
            index++
        }
        document.finishPage(page)
        pageNumber++
    }
    context.contentResolver.openOutputStream(uri).use { output -> requireNotNull(output); document.writeTo(output) }
    document.close()
}

private fun queryDisplayName(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }
}

@Composable
private fun ChessScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Chess Analyzer", color = MainText, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Papan demo untuk rancangan fitur. Engine Stockfish belum dibundel pada build ini.", color = Muted, fontSize = 13.sp)
        val pieces = listOf("♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜", "♟", "♟", "♟", "♟", "♟", "♟", "♟", "♟")
        Column(Modifier.fillMaxWidth().aspectRatio(1f).border(2.dp, Purple, RoundedCornerShape(4.dp))) {
            for (row in 0..7) {
                Row(Modifier.weight(1f)) {
                    for (col in 0..7) {
                        val light = (row + col) % 2 == 0
                        val piece = when {
                            row == 0 -> listOf("♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜")[col]
                            row == 1 -> "♟"
                            row == 6 -> "♙"
                            row == 7 -> listOf("♖", "♘", "♗", "♕", "♔", "♗", "♘", "♖")[col]
                            else -> ""
                        }
                        Box(Modifier.weight(1f).fillMaxHeight().background(if (light) Color(0xFFE2E8F0) else Color(0xFF53627D)), contentAlignment = Alignment.Center) {
                            Text(piece, color = if (row < 2) Color(0xFF172033) else Color(0xFFF8FAFC), fontSize = 24.sp)
                        }
                    }
                }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Evaluasi: —", color = MainText, fontWeight = FontWeight.SemiBold)
                Text("Langkah terbaik: belum tersedia", color = Muted, fontSize = 13.sp)
                Text("Untuk analisis nyata, integrasikan binary Stockfish Android dan parser PGN/FEN.", color = Muted, fontSize = 11.sp)
            }
        }
        OutlinedButton(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("Analisis (engine belum tersedia)") }
    }
}
