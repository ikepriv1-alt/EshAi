# EshAi implementation roadmap

## Milestone 1 — MVP shell
- [x] Jetpack Compose UI
- [x] Chat / Chess Analyzer / Converter tabs
- [x] File selection via Storage Access Framework
- [x] Basic text and image conversions
- [x] Simple text-based PDF output
- [x] GitHub Actions debug build

## Milestone 2 — Real local AI
- [ ] Select a permissively licensed, Indonesian-capable model
- [ ] Integrate LiteRT-LM or llama.cpp
- [ ] Add model manager, memory checks, cancellation, and context limits
- [ ] Add document chunking and grounded file Q&A

## Milestone 3 — Speech and vision
- [ ] Integrate whisper.cpp native Android library and local model weights
- [ ] Add OCR for scanned documents
- [ ] Add image understanding with a compatible on-device vision model

## Milestone 4 — Office documents
- [ ] Select and test Android-compatible DOCX/XLSX/PPTX libraries
- [ ] PDF text extraction and OCR fallback
- [ ] DOCX/PDF rendering and layout tests
- [ ] Spreadsheet and presentation export tests

## Milestone 5 — Chess
- [ ] Bundle/build Stockfish native engine for supported ABIs
- [ ] Implement UCI process/pipe adapter
- [ ] Add PGN and FEN parsing
- [ ] Add legal move handling, evaluation, principal variations, and game review
- [ ] Review GPL-3.0 compliance for distribution
