# EshAi Android — MVP 0.1.0

EshAi is an offline-first Android project starter built with Kotlin and Jetpack Compose. This ZIP is intended to be uploaded to a GitHub repository and built using the included GitHub Actions workflow.

## What works in this MVP
- Android app shell with Chat, Chess Analyzer, and File Converter tabs.
- Local demo chat responses (not a generative LLM).
- Android file picker for arbitrary file selection.
- Basic text conversions for UTF-8 TXT/MD/CSV/HTML/JSON/XML/LOG to TXT, HTML, Markdown, or a simple text-based PDF.
- Basic image conversions between PNG/JPG/WEBP for common image sources.
- Speak-to-write UI using Android's speech recognition intent with an offline preference request. The device's speech service may ignore the offline preference; this is not a guaranteed offline transcription engine.
- GitHub Actions workflow to build a debug APK and upload it as an artifact.

## Not yet implemented (important)
This is a compilable MVP starter, not the fully featured AI product described in the project brief. The following still require separate libraries/models and integration:
- Generative local LLM (LiteRT-LM or llama.cpp); no model weights are bundled.
- Actual Stockfish engine binary and PGN/FEN parser; the chess screen is currently a UI placeholder.
- Full PDF text extraction and scanned-PDF OCR.
- DOCX/XLSX/PPTX import/export and layout-faithful Office/PDF conversion.
- Audio/video conversion, Whisper.cpp integration, archive conversion, and image understanding.

The converter deliberately rejects unsupported source types rather than pretending to convert them. The PDF exporter is a simple text-to-PDF exporter and does not preserve the original layout.

## Build through GitHub
1. Create a repository named `EshAi` on GitHub.
2. Extract this ZIP on your computer.
3. Upload the contents of this folder to the repository root (do not upload the outer ZIP itself).
4. Commit and push to the `main` branch.
5. Open the repository's **Actions** tab. The workflow runs on push, or you can manually run **Build EshAi APK**.
6. Open a successful workflow run and download the `EshAi-debug-apk` artifact.
7. Extract the artifact ZIP to get the APK, then install it on an Android device. You may need to allow installation from your file manager/browser.

## Local build
Install Android Studio and Java 17. The workflow uses Gradle 8.9 and Android SDK 35. From the project root, run:

```bash
gradle assembleDebug
```

Alternatively, open the folder in Android Studio and let it configure Gradle.

## Privacy
The implemented text/image conversion code runs locally. No network permission is declared. Android's speech-recognition service may be provided by the device and may not guarantee offline operation. The demo chat is local canned logic and does not call an online AI service.

## License notes
This starter source is provided for development. Before distributing a complete product, review the licenses of any model weights, native engines, and conversion libraries you add. Stockfish is GPL-3.0; comply with its source and distribution requirements if you bundle or distribute it.
